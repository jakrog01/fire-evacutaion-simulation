#!/usr/bin/env python3

"""
grid_search.py — generator parametrów + worker do pojedynczego runu

Założenia:
- Każdy run ma własny katalog: <EXP_DIR>/runs/<index>_<hash>/
- W run-dir mają się pojawić: metrics.json, loss.json, roi_curves.npz (+ logi)
- Manifest jest pojedynczym plikiem JSONL (1 linia = 1 run) -> nie tworzymy 10k małych plików z góry.
- Worker wspiera restart: jeśli run jest poprawny → skip.

Ważne: ENGINE_CMD_TEMPLATE (env albo --engine-cmd-template) musi być dopasowane do Waszego entrypointu.
Szablon obsługuje placeholdery:
  {run_dir}      -> katalog runu
  {params_json}  -> ścieżka do params.json (w run-dir)

Przykład:
  ENGINE_CMD_TEMPLATE="python run_simulation.py --params {params_json} --outdir {run_dir}"
"""

from __future__ import annotations

import argparse
import dataclasses
import datetime as _dt
import hashlib
import json
import os
import platform
import random
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    import numpy as np
except Exception as e:
    np = None  # type: ignore


# ---------------------------
# Param space (edytuj pod Wasz silnik)
# ---------------------------

@dataclasses.dataclass(frozen=True)
class ParamDef:
    name: str
    kind: str  # "uniform", "loguniform"
    low: float
    high: float
    dtype: str = "float"  # "float" | "int"
    clip: Optional[Tuple[float, float]] = None  # zabezpieczenie anty-outlier (punkt 9)
    note: str = ""


# Domyślne parametry do strojenia (bezpieczne zakresy — do dostosowania pod Waszą domenę)
PARAM_SPACE: List[ParamDef] = [
    ParamDef("ignition_time_s", "uniform", 5.0, 120.0, note="czas zapłonu; zbyt mały może 'oszukiwać' loss"),
    ParamDef("ignition_ramp_s", "uniform", 0.5, 30.0, note="narastanie HRR po zapłonie"),
    ParamDef("hrr_scale", "uniform", 0.70, 1.30, clip=(0.75, 1.25), note="skala HRR; kontrola przed 'głupim' minimalizowaniem"),
    ParamDef("hrr_smooth", "uniform", 0.0, 0.50, note="wygładzanie HRR (jeśli wspierane)"),
    ParamDef("ventilation_scale", "uniform", 0.80, 1.20, clip=(0.85, 1.15), note="skalowanie wentylacji / przepływu"),
    ParamDef("heat_transfer_scale", "uniform", 0.80, 1.20, clip=(0.85, 1.15), note="skalowanie wymiany ciepła"),
    ParamDef("smoke_yield_scale", "uniform", 0.70, 1.30, clip=(0.80, 1.20), note="skalowanie dymu / sadzy"),
    ParamDef("radiative_fraction", "uniform", 0.20, 0.45, clip=(0.22, 0.42), note="frakcja radiacyjna (jeśli wspierane)"),
    ParamDef("objective_clip_q", "uniform", 0.90, 0.995, note="clipping outlierów w celu (punkt 9)"),
]

# Jeśli chcecie jawnie ograniczyć parametry, które mogą oszukać cel,
# dopiszcie tu dodatkowe reguły domenowe.
def apply_domain_constraints(params: Dict[str, Any]) -> Dict[str, Any]:
    # Przykład: jeżeli ignition_time jest bardzo wczesny, nie pozwalaj na ekstremalne hrr_scale.
    t_ign = float(params.get("ignition_time_s", 0.0))
    if t_ign < 15.0 and "hrr_scale" in params:
        params["hrr_scale"] = float(min(max(params["hrr_scale"], 0.85), 1.15))
    return params


# ---------------------------
# Utilities
# ---------------------------

def _stable_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def short_hash(obj: Any, n: int = 10) -> str:
    h = hashlib.sha1(_stable_json(obj).encode("utf-8")).hexdigest()
    return h[:n]


def sha256_file(path: Path, chunk_size: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(chunk_size)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def get_git_commit() -> str:
    try:
        out = subprocess.check_output(["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL, text=True).strip()
        if re.fullmatch(r"[0-9a-f]{40}", out):
            return out
    except Exception:
        pass
    return "unknown"


def get_versions() -> Dict[str, str]:
    versions = {
        "python": sys.version.replace("\n", " "),
        "platform": platform.platform(),
    }
    try:
        import numpy as _np  # noqa
        versions["numpy"] = _np.__version__
    except Exception:
        versions["numpy"] = "not_installed"
    try:
        import numba as _nb  # noqa
        versions["numba"] = _nb.__version__
    except Exception:
        versions["numba"] = "not_installed"
    return versions


def is_finite_json(obj: Any) -> bool:
    # True jeśli wszystkie liczby w JSON są finite (bez NaN/inf)
    if obj is None:
        return True
    if isinstance(obj, (bool, str)):
        return True
    if isinstance(obj, (int,)):
        return True
    if isinstance(obj, float):
        # NaN != NaN, inf sprawdzamy przez abs
        return (obj == obj) and (abs(obj) != float("inf"))
    if isinstance(obj, list):
        return all(is_finite_json(x) for x in obj)
    if isinstance(obj, dict):
        return all(is_finite_json(v) for v in obj.values())
    return True


def validate_run(run_dir: Path) -> Tuple[bool, List[str]]:
    """
    Zwraca (ok, reasons). Fail-fast wg kryteriów:
    - brak loss.json lub roi_curves.npz
    - NaN/inf w loss.json
    - missing_rois niepuste (jeśli pole istnieje)
    - exception przy wczytywaniu roi_curves.npz
    """
    reasons: List[str] = []
    loss_path = run_dir / "loss.json"
    metrics_path = run_dir / "metrics.json"
    curves_path = run_dir / "roi_curves.npz"

    if not loss_path.exists():
        reasons.append("missing loss.json")
    if not curves_path.exists():
        reasons.append("missing roi_curves.npz")
    if not metrics_path.exists():
        reasons.append("missing metrics.json")

    if reasons:
        return False, reasons

    # loss finite?
    try:
        loss_obj = json.loads(loss_path.read_text(encoding="utf-8"))
        if not is_finite_json(loss_obj):
            reasons.append("NaN/inf in loss.json")
    except Exception as e:
        reasons.append(f"cannot_parse_loss_json: {type(e).__name__}: {e}")

    # missing_rois
    try:
        metrics_obj = json.loads(metrics_path.read_text(encoding="utf-8"))
        if isinstance(metrics_obj, dict) and "missing_rois" in metrics_obj:
            mr = metrics_obj.get("missing_rois")
            if isinstance(mr, list) and len(mr) > 0:
                reasons.append(f"missing_rois_nonempty: {len(mr)}")
            elif mr not in (None, [], "") and not isinstance(mr, list):
                reasons.append("missing_rois_invalid_type")
    except Exception as e:
        reasons.append(f"cannot_parse_metrics_json: {type(e).__name__}: {e}")

    # roi_curves readable?
    if np is not None:
        try:
            with np.load(curves_path, allow_pickle=False) as _:
                pass
        except Exception as e:
            reasons.append(f"cannot_load_roi_curves_npz: {type(e).__name__}: {e}")

    return (len(reasons) == 0), reasons


def read_manifest_line(manifest: Path, index: int) -> Dict[str, Any]:
    # JSONL; index odpowiada linii (0-based)
    # sed -n w bash jest OK, ale tu robimy pythonowo i jednoznacznie.
    with manifest.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if i == index:
                return json.loads(line)
    raise IndexError(f"Index {index} out of range for manifest {manifest}")


# ---------------------------
# Sampling (LHS-like, ale prosty i deterministyczny)
# ---------------------------

def _lhs_unit(n: int, d: int, rng: random.Random) -> List[List[float]]:
    """
    Prosty Latin Hypercube:
      - dzielimy [0,1) na n przedziałów i bierzemy jedną próbkę z każdego
      - per wymiar permutujemy próbki
    """
    # base grid
    u = [[0.0] * d for _ in range(n)]
    for j in range(d):
        bins = [(i + rng.random()) / n for i in range(n)]
        rng.shuffle(bins)
        for i in range(n):
            u[i][j] = bins[i]
    return u


def _transform(u: float, p: ParamDef) -> Any:
    # u in [0,1)
    if p.kind == "uniform":
        x = p.low + (p.high - p.low) * u
    elif p.kind == "loguniform":
        # low/high muszą być >0
        x = p.low * ((p.high / p.low) ** u)
    else:
        raise ValueError(f"Unknown kind: {p.kind}")

    if p.clip is not None:
        lo, hi = p.clip
        x = min(max(x, lo), hi)

    if p.dtype == "int":
        return int(round(x))
    return float(x)


def generate_params(n_runs: int, seed: int) -> Iterable[Dict[str, Any]]:
    rng = random.Random(seed)
    d = len(PARAM_SPACE)
    U = _lhs_unit(n_runs, d, rng)

    for i in range(n_runs):
        params: Dict[str, Any] = {}
        for j, p in enumerate(PARAM_SPACE):
            params[p.name] = _transform(U[i][j], p)
        params = apply_domain_constraints(params)
        yield params


# ---------------------------
# Commands
# ---------------------------

def cmd_generate(args: argparse.Namespace) -> None:
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    meta = Path(args.meta) if args.meta else None
    seed = int(args.seed)

    # meta info
    meta_obj: Dict[str, Any] = {
        "created_at": _dt.datetime.now().isoformat(timespec="seconds"),
        "n_runs": int(args.n_runs),
        "seed": seed,
        "method": "lhs",
        "param_space": [dataclasses.asdict(p) for p in PARAM_SPACE],
        "git_commit": get_git_commit(),
        "versions": get_versions(),
    }

    # write manifest
    with out.open("w", encoding="utf-8") as f:
        for i, params in enumerate(generate_params(int(args.n_runs), seed)):
            run_id = f"{i:05d}_{short_hash(params)}"
            rec = {"index": i, "run_id": run_id, "params": params}
            f.write(_stable_json(rec) + "\n")

    if meta is not None:
        meta.parent.mkdir(parents=True, exist_ok=True)
        meta.write_text(json.dumps(meta_obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _write_json_atomic(path: Path, obj: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def cmd_run_task(args: argparse.Namespace) -> int:
    manifest = Path(args.manifest)
    exp_dir = Path(args.exp_dir)
    runs_root = exp_dir / "runs"
    runs_root.mkdir(parents=True, exist_ok=True)

    idx = int(args.index)
    rec = read_manifest_line(manifest, idx)
    run_id = str(rec["run_id"])
    params = dict(rec["params"])

    run_dir = runs_root / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    # Restart support: jeśli jest poprawny run -> skip.
    ok, reasons = validate_run(run_dir)
    if ok:
        print(f"[run_task] {run_id}: already complete -> SKIP")
        return 0

    # attempt counter (w run-dir)
    attempt_path = run_dir / "attempt.txt"
    attempt = 0
    if attempt_path.exists():
        try:
            attempt = int(attempt_path.read_text().strip())
        except Exception:
            attempt = 0

    max_retries = int(args.max_retries)
    engine_cmd_tmpl = args.engine_cmd_template or os.environ.get("ENGINE_CMD_TEMPLATE", "")
    if not engine_cmd_tmpl.strip():
        print("[run_task] ERROR: ENGINE_CMD_TEMPLATE is empty (set env or --engine-cmd-template)", file=sys.stderr)
        return 2

    # input checksums
    input_files = []
    if args.input_files:
        input_files = [Path(p.strip()) for p in args.input_files.split(",") if p.strip()]

    input_hashes: Dict[str, str] = {}
    for p in input_files:
        if p.exists():
            input_hashes[str(p)] = sha256_file(p)
        else:
            input_hashes[str(p)] = "MISSING"

    # params.json (reproducibility)
    params_json = run_dir / "params.json"
    # Zapisujemy "pełny zestaw parametrów", argv/komendę i hashe wejść
    # (seed: manifest seed jest w meta; tu zapisujemy seed użyty do generacji + index)
    params_record: Dict[str, Any] = {
        "run_id": run_id,
        "index": idx,
        "params": params,
        "manifest": str(manifest),
        "engine_cmd_template": engine_cmd_tmpl,
        "input_hashes_sha256": input_hashes,
        "git_commit": get_git_commit(),
        "versions": get_versions(),
        "created_at": _dt.datetime.now().isoformat(timespec="seconds"),
        # seed dla deterministyczności generatora (opcjonalnie)
        "generator_seed": args.generator_seed,
    }
    _write_json_atomic(params_json, params_record)

    log_path = run_dir / "run.log"
    fail_path = run_dir / "FAILED.json"

    # budujemy komendę
    cmd_str = engine_cmd_tmpl.format(run_dir=str(run_dir), params_json=str(params_json))
    cmd_argv = cmd_str if args.shell else cmd_str.split()

    # retry loop (szybkie retry na transient I/O / node issue)
    while True:
        attempt += 1
        attempt_path.write_text(str(attempt) + "\n", encoding="utf-8")

        print(f"[run_task] {run_id}: attempt {attempt}/{1+max_retries}")
        t0 = time.time()

        # call engine
        env = os.environ.copy()
        env["RUN_DIR"] = str(run_dir)
        env["RUN_ID"] = run_id

        # Numba cache: prefer local scratch (ustawione też w sbatch)
        # Jeśli ktoś odpali poza Slurm, to też minimalizujemy I/O.
        env.setdefault("NUMBA_CACHE_DIR", str(run_dir / ".numba_cache_local"))

        with log_path.open("a", encoding="utf-8") as logf:
            logf.write(f"\n===== attempt {attempt} @ {_dt.datetime.now().isoformat(timespec='seconds')} =====\n")
            logf.write(f"CMD: {cmd_str}\n")
            logf.flush()
            try:
                if args.shell:
                    proc = subprocess.run(cmd_str, shell=True, cwd=str(run_dir), env=env,
                                          stdout=logf, stderr=logf, text=True)
                else:
                    proc = subprocess.run(cmd_argv, shell=False, cwd=str(run_dir), env=env,
                                          stdout=logf, stderr=logf, text=True)
                rc = int(proc.returncode)
            except Exception as e:
                rc = 999
                logf.write(f"EXCEPTION while running engine: {type(e).__name__}: {e}\n")

        dt = time.time() - t0
        print(f"[run_task] {run_id}: engine rc={rc} wall={dt:.1f}s")

        ok, reasons = validate_run(run_dir)
        if rc == 0 and ok:
            # mark done
            (run_dir / "DONE").write_text(_dt.datetime.now().isoformat(timespec="seconds") + "\n", encoding="utf-8")
            if fail_path.exists():
                # nie kasujemy automatycznie, ale można.
                pass
            return 0

        # fail-fast: zapisz powody
        fail_rec = {
            "run_id": run_id,
            "index": idx,
            "attempt": attempt,
            "engine_returncode": rc,
            "validation_reasons": reasons,
            "timestamp": _dt.datetime.now().isoformat(timespec="seconds"),
        }
        _write_json_atomic(fail_path, fail_rec)

        if attempt <= max_retries:
            print(f"[run_task] {run_id}: FAILED (will retry). Reasons: {reasons}")
            # krótki backoff
            time.sleep(min(10.0, 1.5 * attempt))
            continue

        print(f"[run_task] {run_id}: FAILED окончательно. Reasons: {reasons}", file=sys.stderr)
        return 1


def cmd_collect(args: argparse.Namespace) -> None:
    exp_dir = Path(args.exp_dir)
    manifest = Path(args.manifest) if args.manifest else exp_dir / "manifest.jsonl"
    runs_root = exp_dir / "runs"

    failed: List[Dict[str, Any]] = []
    missing: List[int] = []
    ok_count = 0

    # iterujemy po manifeście (źródło prawdy)
    with manifest.open("r", encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            idx = int(rec["index"])
            run_id = str(rec["run_id"])
            run_dir = runs_root / run_id
            if not run_dir.exists():
                missing.append(idx)
                continue
            ok, reasons = validate_run(run_dir)
            if ok:
                ok_count += 1
            else:
                failed.append({"index": idx, "run_id": run_id, "reasons": reasons})

    out_dir = exp_dir / "collect"
    out_dir.mkdir(parents=True, exist_ok=True)

    (out_dir / "summary.json").write_text(
        json.dumps({"ok": ok_count, "failed": len(failed), "missing_dirs": len(missing)}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (out_dir / "failed.json").write_text(json.dumps(failed, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (out_dir / "missing_indices.txt").write_text("\n".join(map(str, missing)) + "\n", encoding="utf-8")

    # indeksy do resubmita (tylko failed; missing też można dołączyć)
    failed_indices = [str(x["index"]) for x in failed]
    (out_dir / "failed_indices.txt").write_text("\n".join(failed_indices) + "\n", encoding="utf-8")

    print(f"[collect] ok={ok_count} failed={len(failed)} missing_dirs={len(missing)}")
    print(f"[collect] outputs in: {out_dir}")


def _safe_read_loss(loss_path: Path) -> Optional[float]:
    try:
        obj = json.loads(loss_path.read_text(encoding="utf-8"))
        if isinstance(obj, (int, float)):
            return float(obj)
        if isinstance(obj, dict):
            # common patterns: {"loss": x} albo {"total": x}
            for k in ("loss", "total", "value"):
                if k in obj and isinstance(obj[k], (int, float)):
                    return float(obj[k])
        return None
    except Exception:
        return None


def cmd_report(args: argparse.Namespace) -> None:
    exp_dir = Path(args.exp_dir)
    manifest = Path(args.manifest) if args.manifest else exp_dir / "manifest.jsonl"
    runs_root = exp_dir / "runs"
    k = int(args.k)

    rows: List[Dict[str, Any]] = []
    with manifest.open("r", encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            run_id = str(rec["run_id"])
            run_dir = runs_root / run_id
            if not run_dir.exists():
                continue
            ok, reasons = validate_run(run_dir)
            loss = _safe_read_loss(run_dir / "loss.json") if (run_dir / "loss.json").exists() else None
            # sanity checks (punkt 8) – jeśli metryki mają takie pola
            sanity = {}
            metrics_path = run_dir / "metrics.json"
            if metrics_path.exists():
                try:
                    m = json.loads(metrics_path.read_text(encoding="utf-8"))
                    if isinstance(m, dict):
                        for key in ("chronology_ok", "exit_too_early", "pathology_flags", "exit_reason"):
                            if key in m:
                                sanity[key] = m[key]
                except Exception:
                    pass

            # score: loss + duże kary za brak sanity
            score = float("inf") if (loss is None) else float(loss)
            if not ok:
                score += 1e6
            # twarde warunki jeśli istnieją:
            if sanity.get("chronology_ok") is False:
                score += 1e5
            if sanity.get("exit_too_early") is True:
                score += 1e5
            if isinstance(sanity.get("pathology_flags"), list) and len(sanity["pathology_flags"]) > 0:
                score += 1e4 * len(sanity["pathology_flags"])

            rows.append({
                "run_id": run_id,
                "index": int(rec["index"]),
                "loss": loss,
                "score": score,
                "ok": ok,
                "reasons": reasons,
                **{f"p_{k}": v for k, v in rec["params"].items()},
                **{f"m_{k}": v for k, v in sanity.items()},
            })

    rows.sort(key=lambda r: (r["score"], r["index"]))
    top = rows[:k]

    out_dir = exp_dir / "report"
    out_dir.mkdir(parents=True, exist_ok=True)

    # csv (minimal, bez pandas)
    csv_path = out_dir / f"top{k}.csv"
    cols = list(top[0].keys()) if top else ["run_id","index","loss","score","ok","reasons"]
    with csv_path.open("w", encoding="utf-8") as f:
        f.write(",".join(cols) + "\n")
        for r in top:
            vals = []
            for c in cols:
                v = r.get(c)
                if isinstance(v, (list, dict)):
                    v = _stable_json(v)
                if v is None:
                    v = ""
                s = str(v).replace('"', '""')
                if "," in s or "\n" in s:
                    s = f'"{s}"'
                vals.append(s)
            f.write(",".join(vals) + "\n")

    # opcjonalny bundle top-k (debug dump tylko dla top-k)
    if args.bundle_topk:
        bundle_dir = out_dir / f"top{k}_bundle"
        bundle_dir.mkdir(parents=True, exist_ok=True)
        for r in top:
            src = runs_root / r["run_id"]
            dst = bundle_dir / r["run_id"]
            if dst.exists():
                continue
            # kopiujemy tylko wymagane artefakty + params + log
            dst.mkdir(parents=True, exist_ok=True)
            for fname in ("params.json", "metrics.json", "loss.json", "roi_curves.npz", "run.log", "FAILED.json"):
                p = src / fname
                if p.exists():
                    shutil.copy2(p, dst / fname)

    print(f"[report] wrote: {csv_path}")
    if args.bundle_topk:
        print(f"[report] bundled top{k} into: {out_dir / f'top{k}_bundle'}")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)

    g = sub.add_parser("generate", help="generate manifest.jsonl")
    g.add_argument("--n-runs", type=int, required=True)
    g.add_argument("--seed", type=int, required=True)
    g.add_argument("--out", type=str, required=True)
    g.add_argument("--meta", type=str, default="")
    g.set_defaults(func=cmd_generate)

    r = sub.add_parser("run_task", help="run single task (used by Slurm array)")
    r.add_argument("--manifest", type=str, required=True)
    r.add_argument("--exp-dir", type=str, required=True)
    r.add_argument("--index", type=int, required=True)
    r.add_argument("--max-retries", type=int, default=2)
    r.add_argument("--engine-cmd-template", type=str, default="")
    r.add_argument("--input-files", type=str, default="")
    r.add_argument("--generator-seed", type=str, default="")
    r.add_argument("--shell", action="store_true", help="run engine command through shell")
    r.set_defaults(func=cmd_run_task)

    c = sub.add_parser("collect", help="collect status; writes exp_dir/collect/*")
    c.add_argument("--exp-dir", type=str, required=True)
    c.add_argument("--manifest", type=str, default="")
    c.set_defaults(func=cmd_collect)

    rep = sub.add_parser("report", help="rank + top-k; writes exp_dir/report/*")
    rep.add_argument("--exp-dir", type=str, required=True)
    rep.add_argument("--manifest", type=str, default="")
    rep.add_argument("--k", type=int, default=50)
    rep.add_argument("--bundle-topk", action="store_true")
    rep.set_defaults(func=cmd_report)

    return p


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    rc = args.func(args)
    if isinstance(rc, int):
        return rc
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
