#!/usr/bin/env python3

"""
collect_results.py — zbiera status runów po zakończeniu/awarii kolejki

Użycie:
  python3 collect_results.py --exp-dir experiments/<...>

Wyniki w:
  <exp>/collect/summary.json
  <exp>/collect/failed.json
  <exp>/collect/failed_indices.txt
  <exp>/collect/missing_indices.txt
"""

import argparse
from pathlib import Path
import subprocess
import sys

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--exp-dir", required=True)
    ap.add_argument("--manifest", default="")
    args = ap.parse_args()

    exp = Path(args.exp_dir)
    manifest = args.manifest or str(exp / "manifest.jsonl")

    cmd = [sys.executable, "grid_search.py", "collect", "--exp-dir", str(exp), "--manifest", manifest]
    print("[collect_results] running:", " ".join(cmd))
    return int(subprocess.call(cmd))

if __name__ == "__main__":
    raise SystemExit(main())
