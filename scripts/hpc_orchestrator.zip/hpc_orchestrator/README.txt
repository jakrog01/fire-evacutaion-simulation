HPC Orchestrator (Slurm) — pliki

- submit_jobs.sh        — generuje manifest i wysyła Slurm array
- slurm_array.sbatch    — worker dla array task
- grid_search.py        — generacja parametrów + uruchomienie runu + collect/report
- collect_results.py    — wrapper do collect (oddzielenie postprocessingu)
- report_topk.py        — wrapper do report (top-k + opcjonalny bundle)

Najważniejsze miejsca do dopasowania:
1) ENGINE_CMD_TEMPLATE w submit_jobs.sh — dopasuj do entrypointu silnika.
   Używa {run_dir} i {params_json}.
2) PARAM_SPACE w grid_search.py — zakresy parametrów strojenia.
3) INPUT_FILES w submit_jobs.sh — lista plików do hashy (reproducibility).

Run-dir artifacts:
- params.json (z command template, hashami wejść, wersjami)
- run.log
- oczekiwane od silnika: metrics.json, loss.json, roi_curves.npz

Restart:
- jeśli loss+metrics+roi_curves są poprawne -> SKIP
- jeśli brak/FAIL -> retry w ramach MAX_RETRIES (domyślnie 2)

Numba cache:
- ustawiane na $SLURM_TMPDIR/numba_cache, żeby nie używać shared FS.
