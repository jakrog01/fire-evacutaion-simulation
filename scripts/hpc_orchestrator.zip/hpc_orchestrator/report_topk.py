#!/usr/bin/env python3

"""
report_topk.py — generuje ranking top-k (nie tylko loss)

Użycie:
  python3 report_topk.py --exp-dir experiments/<...> --k 50 --bundle-topk
"""

import argparse
from pathlib import Path
import subprocess
import sys

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--exp-dir", required=True)
    ap.add_argument("--manifest", default="")
    ap.add_argument("--k", type=int, default=50)
    ap.add_argument("--bundle-topk", action="store_true")
    args = ap.parse_args()

    exp = Path(args.exp_dir)
    manifest = args.manifest or str(exp / "manifest.jsonl")

    cmd = [sys.executable, "grid_search.py", "report", "--exp-dir", str(exp), "--manifest", manifest, "--k", str(args.k)]
    if args.bundle_topk:
        cmd.append("--bundle-topk")

    print("[report_topk] running:", " ".join(cmd))
    return int(subprocess.call(cmd))

if __name__ == "__main__":
    raise SystemExit(main())
