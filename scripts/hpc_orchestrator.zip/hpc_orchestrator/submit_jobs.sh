#!/usr/bin/env bash
set -euo pipefail

# --------------------------------------------------------------------
# submit_jobs.sh — generator + submitter dla masowego strojenia (10k runów)
#
# Użycie (przykład):
#   ./submit_jobs.sh \
#     --tag "tune_v1" \
#     --partition topola \
#     --concurrency 200 \
#     --engine-cmd 'python run_simulation.py --params {params_json} --outdir {run_dir}' \
#     --input-files 'data/stationnc.json,data/roi.json,data/objectives.json,data/maps.npz'
#
# Wskazówki:
# - PARTITION ustawiaj zależnie od ICM (topola/okeanos). Skrypt przekazuje to do sbatch.
# - ENGINE_CMD to szablon z placeholderami: {run_dir} oraz {params_json}.
# - INPUT_FILES to lista plików, których checksum ma trafić do params/metrics (reproducibility).
# --------------------------------------------------------------------

TAG="exp"
PARTITION="topola"
CONCURRENCY="200"
N_RUNS="10000"
SEED="20260122"
TIME_LIMIT="00:20:00"   # szacunek + 10% bufor (zmień po pilocie)
MEM_LIMIT="5G"          # szacunek + 10% bufor (zmień po pilocie)
CPUS="2"
ENGINE_CMD='python run_simulation.py --params {params_json} --outdir {run_dir}'
INPUT_FILES="data/stationnc.json,data/roi.json,data/objectives.json,data/maps.npz"
EXTRA_SBATCH_ARGS=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --tag) TAG="$2"; shift 2 ;;
    --partition) PARTITION="$2"; shift 2 ;;
    --concurrency) CONCURRENCY="$2"; shift 2 ;;
    --n-runs) N_RUNS="$2"; shift 2 ;;
    --seed) SEED="$2"; shift 2 ;;
    --time) TIME_LIMIT="$2"; shift 2 ;;
    --mem) MEM_LIMIT="$2"; shift 2 ;;
    --cpus) CPUS="$2"; shift 2 ;;
    --engine-cmd) ENGINE_CMD="$2"; shift 2 ;;
    --input-files) INPUT_FILES="$2"; shift 2 ;;
    --sbatch-args) EXTRA_SBATCH_ARGS="$2"; shift 2 ;;
    *)
      echo "Nieznany argument: $1" >&2
      exit 2
      ;;
  esac
done

ts="$(date +%Y%m%d_%H%M%S)"
EXP_DIR="experiments/${ts}_${TAG}"
mkdir -p "${EXP_DIR}/runs" "${EXP_DIR}/logs"

MANIFEST="${EXP_DIR}/manifest.jsonl"
META="${EXP_DIR}/manifest_meta.json"

echo "[submit_jobs] EXP_DIR=${EXP_DIR}"
echo "[submit_jobs] Generuję manifest (${N_RUNS} runów, seed=${SEED})..."

python3 grid_search.py generate \
  --n-runs "${N_RUNS}" \
  --seed "${SEED}" \
  --out "${MANIFEST}" \
  --meta "${META}"

echo "[submit_jobs] Submitting Slurm array..."
# UWAGA: --array=0-9999%CONCURRENCY ogranicza liczbę jednoczesnych tasków.
sbatch \
  --partition="${PARTITION}" \
  --array="0-$((N_RUNS-1))%${CONCURRENCY}" \
  --cpus-per-task="${CPUS}" \
  --mem="${MEM_LIMIT}" \
  --time="${TIME_LIMIT}" \
  --job-name="tune_${TAG}" \
  --output="${EXP_DIR}/logs/%A_%a.out" \
  --error="${EXP_DIR}/logs/%A_%a.err" \
  --export=ALL,EXP_DIR="${EXP_DIR}",MANIFEST="${MANIFEST}",ENGINE_CMD_TEMPLATE="${ENGINE_CMD}",INPUT_FILES="${INPUT_FILES}",MAX_RETRIES="2" \
  ${EXTRA_SBATCH_ARGS} \
  slurm_array.sbatch

echo "[submit_jobs] OK. Następne kroki:"
echo "  - collect: python3 collect_results.py --exp-dir ${EXP_DIR}"
echo "  - report : python3 report_topk.py --exp-dir ${EXP_DIR} --k 50"
